package com.example.googlemap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap map;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this); //getmapAsync digunakan untuk menjalankan
        //method yang hanya disediakan oleh google ma
    }
    @Override
    public void onMapReady(GoogleMap googleMap){
        map = googleMap; //diambil dari google map

        LatLng SDnPetamanan= new LatLng(-7.654112, 112.905946); //koordinat lokasi
        map.addMarker(new MarkerOptions().position(SDnPetamanan).title("SDn Petamanan Kota Pasuruan, Jawa Timur")); //penamaan lokasi
        //addmarke : menambahkan marker tunggal pada peta
        map.moveCamera(CameraUpdateFactory.newLatLng(SDnPetamanan));
    }
}
